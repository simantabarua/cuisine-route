import React from 'react'

const App = () => {
  return (
    <div>App

      <h2 className='text-4xl'>df</h2>
    </div>
  )
}

export default App