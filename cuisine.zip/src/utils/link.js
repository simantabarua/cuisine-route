export const links = [
  { label: "Home", path: "/" },
  { label: "About", path: "/about" },
  { label: "Blogs", path: "/blogs" },
  { label: "Recipes", path: "/recipes" },
];
